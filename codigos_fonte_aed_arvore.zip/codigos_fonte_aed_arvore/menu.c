#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "curso.h"
#include "disciplina.h"
#include "professor.h"
#include "distribuicao.h"
#include "lote.h"

// Fun��o que imprime o cabe�alho do menu principal.
// Pr�-condi��o: Nenhuma
// P�s-condi��o: Nenhuma
void header_menu(){
    printf(" ----------MENU---------\n");
    printf("| 1 - Cadastrar         |\n");
    printf("| 2 - Remover           |\n");
    printf("| 3 - Imprimir          |\n");
    printf("| 4 - Carregar arquivo  |\n");
    printf("| 5 - Encerrar programa |\n");
    printf(" ----------------------- \n");
}

// Fun��o que imprime o cabe�alho do menu de cadastro.
// Pr�-condi��o: Nenhuma
// P�s-condi��o: Nenhuma
void header_cadastrar(){
    printf(" ------------------CADASTRAR--------------- \n");
    printf("| 1 - Cadastrar curso                      |\n");
    printf("| 2 - Cadastrar disciplina                 |\n");
    printf("| 3 - Cadastrar professor                  |\n");
    printf("| 4 - Cadastrar distribuicao de disciplina |\n");
    printf("| 5 - Voltar ao menu principal             |\n");
    printf(" ------------------------------------------ \n");
}

// Fun��o que imprime o cabe�alho do menu de remo��o.
// Pr�-condi��o: Nenhuma
// P�s-condi��o: Nenhuma
void header_remover(){
    printf(" ------------------REMOVER--------------- \n");
    printf("| 1 - Remover distribuicao de disciplina |\n");
    printf("| 2 - Voltar ao menu principal           |\n");
    printf(" ---------------------------------------- \n");
}

// Fun��o que imprime o cabe�alho do menu de impress�o.
// Pr�-condi��o: Nenhuma
// P�s-condi��o: Nenhuma
void header_imprimir(){
    printf(" ---------------------------------IMPRIMIR-------------------------------- \n");
    printf("| 1 - Imprimir lista de cursos                                            |\n");
    printf("| 2 - Imprimir lista de disciplinas                                       |\n");
    printf("| 3 - Imprimir lista de professores                                       |\n");
    printf("| 4 - Imprimir lista de distribuicao de disciplina, organizadas por codigo |\n");
    printf("| 5 - Imprimir lista de posi��es livres no arquivo de dist. de disciplina |\n");
    printf("| 6 - Imprimir distribui��es por n�vel                                    |\n");
    printf("| 7 - Voltar ao menu principal                                            |\n");
    printf(" ------------------------------------------------------------------------- \n");
}

// Fun��o que imprime o cabe�alho do menu de carregar arquivo.
// Pr�-condi��o: Nenhuma
// P�s-condi��o: Nenhuma
void header_carregar_arquivo(){
    printf(" -----CARREGAR ARQUIVO---------- \n");
    printf("| 1 - Carregar arquivo de lote: |\n");
    printf("| 2 - Voltar ao menu principal  |\n");
    printf(" ------------------------------- \n");
}

// Fun��o que implementa o menu de cadastro.
// Pr�-condi��o: ARQUIVOS files deve ser v�lida.
// P�s-condi��o: Pode ter realizado opera��es de cadastro e voltado ao menu principal.
void menu_cadastrar(ARQUIVOS files){
    int opcao;

    header_cadastrar();
    printf("--> OPCAO: ");
    scanf("%d", &opcao);
    printf("\n");

    switch(opcao){
        case 1:
            inserir_curso(files.file_curso);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 2:
            inserir_disciplina(files.file_disciplina);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;

        case 3:
            inserir_professor(files.file_professor);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 4:
            printf("\n--> Cadastro de distribuicao de disciplina: \n");
            inserir_distribuicao(files.file_distribuicao);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 5:
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        default:
            printf("\n--> Esse numero e opcao invalida\n\n");
            menu_cadastrar(files);
            break;
    }
}

// Fun��o que implementa o menu de remo��o.
// Pr�-condi��o: ARQUIVOS files deve ser v�lida.
// P�s-condi��o: Pode ter removido uma distribui��o de disciplina e voltado ao menu principal.
void menu_remover(ARQUIVOS files){
    int opcao;

    header_remover();
    printf("--> OPCAO: ");
    scanf("%d", &opcao);
    printf("\n");

    switch(opcao){
        case 1:
            printf("\n--> Remover distribuicao de disciplina: \n");
            retira_distribuicao(files.file_distribuicao);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 2:
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        default:
            printf("\n--> Esse numero e opcao invalida\n\n");
            menu_remover(files);
            break;
    }
}

// Fun��o que implementa o menu de impress�o.
// Pr�-condi��o: ARQUIVOS files deve ser v�lida.
// P�s-condi��o: Pode ter realizado opera��es de impress�o e voltado ao menu principal.
void menu_imprimir(ARQUIVOS files){
    int opcao;

    header_imprimir();
    printf("--> OPCAO: ");
    scanf("%d", &opcao);
    printf("\n");

    switch(opcao){
        case 1:
            imprimir_lista_cursos(files.file_curso);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 2:
            imprimir_lista_disciplinas(files);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 3:
            imprimir_lista_professor(files.file_professor);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 4:
            imprimir_lista_distribuicao(files);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 5:
            imprimir_posicoes_livres_wrapper(files.file_distribuicao);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 6:
            imprimir_niveis(files.file_distribuicao);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 7:
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        default:
            printf("\n--> Esse numero e opcao invalida\n\n");
            menu_imprimir(files);
            break;
    }
}

void menu_carregar_arquivo(ARQUIVOS files){
    int opcao;

    header_carregar_arquivo();
    printf("--> OPCAO: ");
    scanf("%d%*c", &opcao);
    printf("\n");

    switch(opcao){
        case 1:
            ler_lote(files);
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        case 2:
            printf("\n--> Voltando ao menu principal\n\n");
            menu_principal(files);
            break;
        default:
            printf("\n--> Esse numero e opcao invalida\n\n");
            menu_carregar_arquivo(files);
            break;
    }
}


// Fun��o que implementa o menu principal.
// Pr�-condi��o: ARQUIVOS files deve ser v�lida.
// P�s-condi��o: Pode ter realizado opera��es correspondentes � escolha do usu�rio.
void menu_principal(ARQUIVOS files){
    int opcao;
    header_menu();
    printf("--> OPCAO: ");
    scanf("%d", &opcao);
    printf("\n");

    switch(opcao){
        case 1:
            menu_cadastrar(files);
            break;
        case 2:
            menu_remover(files);
            break;
        case 3:
            menu_imprimir(files);
            break;
        case 4:
            menu_carregar_arquivo(files);
            break;
        case 5:
            printf("\n--> Encerrando programa\n\n");
            break;
        default:
            printf("\n--> Esse numero e opcao invalida\n\n");
            menu_principal(files);
            break;
    }
}
