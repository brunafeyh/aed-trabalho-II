#ifndef CURSO_H
#define CURSO_H
#define MAXS 51

#include "cabecalho.h"
#include "file.h"

// Defini��o da estrutura GRADUACAO
typedef struct {
    int codigo;          // C�digo da gradua��o
    char nome[MAXS];      // Nome da gradua��o, com tamanho m�ximo definido por MAXS
    char area;            // �rea da gradua��o
} GRADUACAO;

// Defini��o da estrutura NO_CURSO, que cont�m uma GRADUACAO e ponteiros para os nodos da �rvore
typedef struct {
    GRADUACAO curso;      // Informa��es sobre o curso de gradua��o
    int dir;              // posicao no da sub�rvore direita
    int esq;              // Pposicao no da sub�rvore esquerda
} NO_CURSO;

// Fun��o para ler as informa��es de um curso do usu�rio e retornar uma struct GRADUACAO
// Pr�-condi��o: Nenhuma
// P�s-condi��o: Retorna uma struct GRADUACAO com as informa��es do curso inseridas pelo usu�rio
GRADUACAO ler_curso();

// Fun��o para ler um n� em uma determinada posi��o do arquivo
// Pr�-condi��o: O arquivo deve estar aberto e ser um arquivo de lista, pos deve ser uma posi��o v�lida da lista
// P�s-condi��o: Retorna um ponteiro para o n� lido do arquivo
NO_CURSO * le_no_curso(FILE* file_curso, int pos);

// Fun��o para escrever um n� em uma determinada posi��o do arquivo
// Pr�-condi��o: O arquivo deve estar aberto e ser um arquivo de lista, pos deve ser uma posi��o v�lida do arquivo
// P�s-condi��o: O n� � escrito no arquivo na posi��o especificada
void escreve_no_curso(FILE* file_curso, NO_CURSO * graduacao, int pos);

// Fun��o para buscar um curso no arquivo pelo c�digo
// Pr�-condi��o: O arquivo deve estar aberto, cod � o c�digo a ser buscado, pos � a posi��o inicial da busca
// P�s-condi��o: Retorna a posi��o do curso com o c�digo especificado, -1 se n�o encontrado
int buscar_curso(FILE * file_curso, int cod, int pos);

// Fun��o para buscar um n� de curso no arquivo pelo c�digo
// Pr�-condi��o: O arquivo deve estar aberto, cod � o c�digo a ser buscado, pos � a posi��o inicial da busca
// P�s-condi��o: Retorna o n� curso com o c�digo especificado, NULL se n�o encontrado
NO_CURSO * buscar_no_curso(FILE * file_curso, int cod, int pos);

// Fun��o para buscar um n� de curso no arquivo pelo c�digo
// Pr�-condi��o: O arquivo deve estar aberto, cod � o c�digo a ser buscado, pos � a posi��o inicial da busca
// P�s-condi��o: Retorna o n� curso com o c�digo especificado, NULL se n�o encontrado
NO_CURSO * buscar_info_curso(ARQUIVOS files, int codigo);

// Fun��o para inserir um curso no arquivo
// Pr�-condi��o: O arquivo deve estar aberto
// P�s-condi��o: O curso � inserido no arquivo, e uma mensagem � exibida indicando o resultado da opera��o
void inserir_curso(FILE* file_curso);

// Fun��o para inserir um curso no arquivo proveniente do arquivo lote txt
// Pr�-condi��o: O arquivo deve estar aberto
// P�s-condi��o: O curso � inserido no arquivo, e uma mensagem � exibida indicando o resultado da opera��o
void inserir_curso_do_lote(FILE* file_curso, GRADUACAO graduacao);

// Fun��o para inserir um n� contendo as informa��es do curso em uma determinada posi��o do arquivo
// Pr�-condi��o: O arquivo deve estar aberto
// P�s-condi��o: O n� � escrito no arquivo na posi��o apropriada, e o cabe�alho � atualizado se necess�rio
void inserir_curso_rec(FILE* file_curso, NO_CURSO * no_curso, int pos, CABECALHO * cab);

// Fun��o para imprimir as informa��es de um curso contidas em um n�
// Pr�-condi��o: O n� deve ser v�lido
// P�s-condi��o: As informa��es do curso no n� s�o impressas na tela
void imprimir_info_curso(NO_CURSO * no_graduacao);

// Fun��o para imprimir os cursos em ordem no arquivo
// Pr�-condi��o: O arquivo deve estar aberto e conter cursos
// P�s-condi��o: Os cursos s�o impressos em ordem na tela
void imprimir_in_order_curso(FILE* file_curso, int pos_atual);

// Fun��o para imprimir todos os cursos em ordem no arquivo
// Pr�-condi��o: O arquivo deve estar aberto
// P�s-condi��o: Os cursos s�o impressos em ordem na tela
void imprimir_lista_cursos(FILE* file_curso);

#endif //CURSO_H
