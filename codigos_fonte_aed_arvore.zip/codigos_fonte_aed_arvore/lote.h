#ifndef LOTE_H
#define LOTE_H
#include "file.h"

// Função para ler um arquivo lote e registrar as informações nos arquivos específicos.
// Pré-condição: Os arquivos no parâmetro 'files' devem estar abertos para leitura/escrita.
// Pós-condição: As informações do arquivo lote são registradas nos arquivos específicos de acordo com a operação.
void ler_lote(ARQUIVOS files);

// Função para registrar um curso lido de um arquivo lote no arquivo de cursos.
// Pré-condição: Os arquivos 'file_lote' e 'file_curso' devem estar abertos.
//                O formato do arquivo lote deve ser consistente com as informações esperadas.
// Pós-condição: O curso lido do arquivo lote é registrado no arquivo de cursos.
void registrar_lote_curso(FILE * file_lote, FILE * file_curso);

// Função para registrar uma disciplina lida de um arquivo lote no arquivo de disciplinas.
// Pré-condição: Os arquivos 'file_lote' e 'file_disciplina' devem estar abertos.
//                O formato do arquivo lote deve ser consistente com as informações esperadas.
// Pós-condição: A disciplina lida do arquivo lote é registrada no arquivo de disciplinas.
void registrar_lote_disciplina(FILE * file_lote, FILE * file_disciplina);

// Função para registrar um professor lido de um arquivo lote no arquivo de professores.
// Pré-condição: Os arquivos 'file_lote' e 'file_professor' devem estar abertos.
//                O formato do arquivo lote deve ser consistente com as informações esperadas.
// Pós-condição: O professor lido do arquivo lote é registrado no arquivo de professores.
void registrar_lote_professor(FILE * file_lote, FILE * file_professor);

// Função para registrar uma distribuição lida de um arquivo lote no arquivo de distribuições.
// Pré-condição: Os arquivos 'file_lote' e 'file_distribuicao' devem estar abertos.
//                O formato do arquivo lote deve ser consistente com as informações esperadas.
// Pós-condição: A distribuição lida do arquivo lote é registrada no arquivo de distribuições.
void registrar_lote_distribuicao(FILE * file_lote, FILE * file_distribuicao);

// Função para remover uma distribuição identificada no arquivo de distribuições usando informações do arquivo lote.
// Pré-condição: Os arquivos 'file_lote' e 'file_distribuicao' devem estar abertos.
// Pós-condição: A distribuição identificada no arquivo lote é removida do arquivo de distribuições.
void remove_distribuicao(FILE *file_lote, FILE *file_distribuicao);


#endif //LOTE_H
