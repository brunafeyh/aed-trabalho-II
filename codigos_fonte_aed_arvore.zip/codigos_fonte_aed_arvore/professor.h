#ifndef PROFESSOR_H
#define PROFESSOR_H
#define MAXS 51

#include "file.h"
#include "curso.h"

// Definição da estrutura PROFESSOR, que armazena informações sobre um professor
typedef struct {
    int codigo;  // Código identificador do professor
    char nome[MAXS];  // Nome do professor
} PROFESSOR;

// Definição da estrutura NO_PROFESSOR, que representa um nó na árvore de professores
typedef struct {
    PROFESSOR professor;  // Informações do professor
    int esq;  // Índice do nó filho à esquerda na árvore
    int dir;  // Índice do nó filho à direita na árvore
} NO_PROFESSOR;

// Função para ler informações de um professor a partir da entrada padrão
// Pré-condição: Nenhuma.
// Pós-condição: Retorna um professor com dados lidos da entrada padrão.
PROFESSOR ler_professor();

// Função para ler um nó de professor de um arquivo na posição 'pos'
// Pré-condição: O arquivo está aberto e na posição 'pos' contém um nó de professor.
// Pós-condição: Retorna um ponteiro para o nó de professor lido do arquivo.
NO_PROFESSOR * le_no_professor(FILE* file_professor, int pos);

// Função para escrever um nó de professor em um arquivo na posição 'pos'
// Pré-condição: O arquivo está aberto e o ponteiro 'no_professor' aponta para um nó de professor válido.
// Pós-condição: O nó de professor é escrito no arquivo na posição 'pos'.
void escreve_no_professor(FILE* file_professor, NO_PROFESSOR * no_professor, int pos);

// Função para inserir um nó de professor em um arquivo na posição 'pos'
// Pré-condição: O arquivo está aberto e o ponteiro 'no_professor' aponta para um nó de professor válido.
// Pós-condição: O nó de professor é inserido no arquivo na posição 'pos'.
void inserir_professor_file(FILE* file_professor, NO_PROFESSOR * no_professor, int pos);

// Função para inserir um novo professor no arquivo
// Pré-condição: O arquivo está aberto e no formato correto.
// Pós-condição: Um novo nó de professor é inserido no arquivo.
void inserir_professor(FILE* file_professor);

// Função para inserir um novo professor no arquivo proveniente do arquivo lote txt.
// Pré-condição: O arquivo está aberto e no formato correto.
// Pós-condição: Um novo nó de professor é inserido no arquivo.
void inserir_professor_do_lote(FILE* file_professor, PROFESSOR professor);

// Função para imprimir as informações de um nó de professor
// Pré-condição: O ponteiro 'no_professor' aponta para um nó de professor válido.
// Pós-condição: As informações do nó de professor são impressas na saída padrão.
void imprimir_info_professor(NO_PROFESSOR * no_professor);

// Função para imprimir em ordem (in-order) as informações dos professores na árvore a partir de um nó inicial
// Pré-condição: O arquivo 'file_professor' está aberto e contém dados válidos, 'pos_atual' é um índice válido na árvore.
// Pós-condição: As informações dos professores são impressas em ordem crescente a partir do nó com índice 'pos_atual'.
void imprimir_in_order_professor(FILE* file_professor, int pos_atual);

// Função para imprimir a lista de professores em ordem a partir do arquivo
// Pré-condição: O arquivo 'file_professor' está aberto e contém dados válidos.
// Pós-condição: As informações dos professores são impressas em ordem crescente de código.
void imprimir_lista_professor(FILE* file_professor);

// Função para buscar um professor no arquivo pelo código, retorna a posição do professor se encontrado, -1 se não encontrado
// Pré-condição: O arquivo está aberto e no formato correto.
// Pós-condição: Retorna a posição do professor no arquivo se encontrado, -1 caso contrário.
int buscar_professor(FILE * file_professor, int cod, int pos);

#endif // PROFESSOR_H
