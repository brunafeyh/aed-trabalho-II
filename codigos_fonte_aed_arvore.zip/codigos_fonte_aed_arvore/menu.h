#ifndef MENU_H
#define MENU_H
#include "file.h"

// Função que imprime o cabeçalho do menu principal.
// Pré-condição: Nenhuma
// Pós-condição: Nenhuma
void header_menu();

// Função que imprime o cabeçalho do menu de cadastro.
// Pré-condição: Nenhuma
// Pós-condição: Nenhuma
void header_cadastrar();

// Função que imprime o cabeçalho do menu de remoção.
// Pré-condição: Nenhuma
// Pós-condição: Nenhuma
void header_remover();

// Função que imprime o cabeçalho do menu de impressão.
// Pré-condição: Nenhuma
// Pós-condição: Nenhuma
void header_imprimir();

// Função que imprime o cabeçalho do menu de carregar arquivo.
// Pré-condição: Nenhuma
// Pós-condição: Nenhuma
void header_carregar_arquivo();

// Função que implementa o menu de cadastro.
// Pré-condição: ARQUIVOS files deve ser válida.
// Pós-condição: Pode ter realizado operações de cadastro e voltado ao menu principal.
void menu_cadastrar(ARQUIVOS files);

// Função que implementa o menu de remoção.
// Pré-condição: ARQUIVOS files deve ser válida.
// Pós-condição: Pode ter removido uma distribuição de disciplina e voltado ao menu principal.
void menu_remover(ARQUIVOS files);

// Função que implementa o menu de impressão.
// Pré-condição: ARQUIVOS files deve ser válida.
// Pós-condição: Pode ter realizado operações de impressão e voltado ao menu principal.
void menu_imprimir(ARQUIVOS files);

// Função que implementa para leitura de arquivo em lote.
// Pré-condição: ARQUIVOS files deve ser válida.
// Pós-condição: Pode ter realizado operações correspondentes à escolha do usuário.
void menu_carregar_arquivo(ARQUIVOS files);

// Função que implementa o menu principal.
// Pré-condição: ARQUIVOS files deve ser válida.
// Pós-condição: Pode ter realizado operações correspondentes à escolha do usuário.
void menu_principal(ARQUIVOS files);

#endif //MENU_H
