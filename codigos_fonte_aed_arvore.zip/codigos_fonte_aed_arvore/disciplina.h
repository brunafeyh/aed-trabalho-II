#ifndef DISCIPLINA_H
#define DISCIPLINA_H
#define MAXS 51

#include "file.h"
#include "curso.h"

// Definição da estrutura DISCIPLINA
typedef struct {
    int codigo;         // Código da disciplina
    char nome[MAXS];     // Nome da disciplina, com tamanho máximo definido por MAXS
    int cod_curso;      // Código do curso associado à disciplina
    int serie;          // Número da série em que a disciplina é ministrada
} DISCIPLINA;

// Definição da estrutura NO_DISCIPLINA, que contém uma DISCIPLINA e ponteiros para os nodos da árvore
typedef struct {
    DISCIPLINA disciplina;  // Informações sobre a disciplina
    int esq;                // Posicao no da subárvore esquerda
    int dir;                // Posicao no da subárvore direita
} NO_DISCIPLINA;

// Função para ler as informações de uma disciplina do usuário e retornar uma struct DISCIPLINA
// Pré-condição: Nenhuma
// Pós-condição: Retorna uma struct DISCIPLINA com as informações da disciplina inseridas pelo usuário
DISCIPLINA ler_disciplina();

// Função para ler um nó em uma determinada posição do arquivo
// Pré-condição: O arquivo deve estar aberto e ser um arquivo de lista, pos deve ser uma posição válida da lista
// Pós-condição: Retorna um ponteiro para o nó lido do arquivo
NO_DISCIPLINA * le_no_disciplina(FILE* file_disciplina, int pos);

// Função para escrever um nó em uma determinada posição do arquivo
// Pré-condição: O arquivo deve estar aberto e ser um arquivo de lista, pos deve ser uma posição válida do arquivo
// Pós-condição: O nó é escrito no arquivo na posição especificada
void escreve_no_disciplina(FILE* file_disciplina, NO_DISCIPLINA * disciplina, int pos);

// Função para inserir um nó contendo as informações da disciplina em uma determinada posição do arquivo
// Pré-condição: O arquivo deve estar aberto
// Pós-condição: O nó é escrito no arquivo na posição apropriada, e o cabeçalho é atualizado se necessário
void inserir_disciplina_file(FILE* file_disciplina, NO_DISCIPLINA * no_disciplina, int pos);

// Função para buscar uma disciplina no arquivo pelo código
// Pré-condição: O arquivo deve estar aberto, cod é o código a ser buscado, pos é a posição inicial da busca
// Pós-condição: Retorna a posição da disciplina com o código especificado, -1 se não encontrado
int buscar_disciplina(FILE * file_disciplina, int cod, int pos);

// Função para inserir uma disciplina no arquivo
// Pré-condição: O arquivo deve estar aberto
// Pós-condição: A disciplina é inserida no arquivo, e uma mensagem é exibida indicando o resultado da operação
void inserir_disciplina(FILE* file_disciplina);

// Função para inserir uma disciplina no arquivo proveniente do arquivo lote txt
// Pré-condição: O arquivo deve estar aberto
// Pós-condição: A disciplina é inserida no arquivo, e uma mensagem é exibida indicando o resultado da operação
void inserir_disciplina_do_lote(FILE* file_disciplina, DISCIPLINA disciplina);

// Função para imprimir as informações de uma disciplina contidas em um nó
// Pré-condição: O nó deve ser válido
// Pós-condição: As informações da disciplina no nó são impressas na tela
void imprimir_info_disciplina(NO_DISCIPLINA * no_disciplina, NO_CURSO * no_curso) ;

// Função para imprimir as disciplinas em ordem no arquivo
// Pré-condição: O arquivo deve estar aberto e conter disciplinas
// Pós-condição: As disciplinas são impressas em ordem na tela
void imprimir_in_order_disciplina(ARQUIVOS files, int pos_atual);

// Função de utilidade para imprimir todas as disciplinas em ordem
// Pré-condição: O arquivo deve estar aberto
// Pós-condição: As disciplinas são impressas em ordem na tela
void imprimir_lista_disciplinas(ARQUIVOS files);

#endif //DISCIPLINA_H
