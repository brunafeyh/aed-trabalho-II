#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "lote.h"
#include "curso.h"
#include "disciplina.h"
#include "professor.h"
#include "distribuicao.h"

// Fun��o para registrar um curso lido de um arquivo lote no arquivo de cursos.
// Pr�-condi��o: Os arquivos 'file_lote' e 'file_curso' devem estar abertos.
//                O formato do arquivo lote deve ser consistente com as informa��es esperadas.
// P�s-condi��o: O curso lido do arquivo lote � registrado no arquivo de cursos.
void registrar_lote_curso(FILE *file_lote, FILE *file_curso) {
    GRADUACAO curso;

    if (fscanf(file_lote, "%d;", &curso.codigo) != 1) {
        fprintf(stderr, "Erro ao ler c�digo do curso\n");
        exit(EXIT_FAILURE);
    }
    if (fscanf(file_lote, "%49[^;]%*c", curso.nome) != 1) {
        fprintf(stderr, "Erro ao ler nome do curso\n");
        exit(EXIT_FAILURE);
    }
    if (fscanf(file_lote, " %c%*c", &curso.area) != 1) {
        fprintf(stderr, "Erro ao ler �rea do curso\n");
        exit(EXIT_FAILURE);
    }

    inserir_curso_do_lote(file_curso, curso);
}

// Fun��o para registrar uma disciplina lida de um arquivo lote no arquivo de disciplinas.
// Pr�-condi��o: Os arquivos 'file_lote' e 'file_disciplina' devem estar abertos.
//                O formato do arquivo lote deve ser consistente com as informa��es esperadas.
// P�s-condi��o: A disciplina lida do arquivo lote � registrada no arquivo de disciplinas.
void registrar_lote_disciplina(FILE *file_lote, FILE *file_disciplina) {
    DISCIPLINA disciplina;

    if (fscanf(file_lote, "%d;", &disciplina.codigo) != 1) {
        fprintf(stderr, "Erro ao ler c�digo da disciplina\n");
        exit(EXIT_FAILURE);
    }
    if (fscanf(file_lote, "%49[^;]%*c", disciplina.nome) != 1) {
        fprintf(stderr, "Erro ao ler nome da disciplina\n");
        exit(EXIT_FAILURE);
    }
    if (fscanf(file_lote, "%d;", &disciplina.cod_curso) != 1) {
        fprintf(stderr, "Erro ao ler c�digo do curso da disciplina\n");
        exit(EXIT_FAILURE);
    }
    if (fscanf(file_lote, "%d%*c", &disciplina.serie) != 1) {
        fprintf(stderr, "Erro ao ler s�rie da disciplina\n");
        exit(EXIT_FAILURE);
    }

    inserir_disciplina_do_lote(file_disciplina, disciplina);
}

// Fun��o para registrar um professor lido de um arquivo lote no arquivo de professores.
// Pr�-condi��o: Os arquivos 'file_lote' e 'file_professor' devem estar abertos.
//                O formato do arquivo lote deve ser consistente com as informa��es esperadas.
// P�s-condi��o: O professor lido do arquivo lote � registrado no arquivo de professores.
void registrar_lote_professor(FILE *file_lote, FILE *file_professor) {
    PROFESSOR professor;

    if (fscanf(file_lote, "%d;", &professor.codigo) != 1) {
        fprintf(stderr, "Erro ao ler c�digo do professor\n");
        exit(EXIT_FAILURE);
    }
    if (fscanf(file_lote, "%49[^\n]%*c", professor.nome) != 1) {
        fprintf(stderr, "Erro ao ler nome do professor\n");
        exit(EXIT_FAILURE);
    }

    inserir_professor_do_lote(file_professor, professor);
}

// Fun��o para registrar uma distribui��o lida de um arquivo lote no arquivo de distribui��es.
// Pr�-condi��o: Os arquivos 'file_lote' e 'file_distribuicao' devem estar abertos.
//                O formato do arquivo lote deve ser consistente com as informa��es esperadas.
// P�s-condi��o: A distribui��o lida do arquivo lote � registrada no arquivo de distribui��es.
void registrar_lote_distribuicao(FILE *file_lote, FILE *file_distribuicao) {
    DISTRIBUICAO distribuicao;

    if (fscanf(file_lote, "%d;", &distribuicao.cod_disciplina) != 1) {
        fprintf(stderr, "Erro ao ler c�digo da disciplina na distribui��o\n");
        exit(EXIT_FAILURE);
    }
    if (fscanf(file_lote, "%4s;", distribuicao.ano_letivo) != 1) {
        fprintf(stderr, "Erro ao ler ano letivo na distribui��o\n");
        exit(EXIT_FAILURE);
    }
    if (fscanf(file_lote, "%d%*c", &distribuicao.cod_professor) != 1) {
        fprintf(stderr, "Erro ao ler c�digo do professor na distribui��o\n");
        exit(EXIT_FAILURE);
    }

    formatar_codigo(distribuicao.cod_disciplina, distribuicao.ano_letivo, distribuicao.cod_distribuicao);

    inserir_distribuicao_do_lote(file_distribuicao, distribuicao);
}

// Fun��o para remover uma distribui��o identificada no arquivo de distribui��es usando informa��es do arquivo lote.
// Pr�-condi��o: Os arquivos 'file_lote' e 'file_distribuicao' devem estar abertos.
// P�s-condi��o: A distribui��o identificada no arquivo lote � removida do arquivo de distribui��es.
void remove_distribuicao(FILE *file_lote, FILE *file_distribuicao){
    int codigo;
    char ano_letivo[5];
    char chave[10];
    CABECALHO* cab = le_cabecalho(file_distribuicao);

    fscanf(file_lote, "%d;%4s\n", &codigo, ano_letivo);
    formatar_codigo(codigo, ano_letivo, chave);

    remover_no_distribuicao(file_distribuicao, cab->pos_raiz, chave);

    free(cab);
}

// Fun��o para ler um arquivo lote e registrar as informa��es nos arquivos espec�ficos.
// Pr�-condi��o: Os arquivos no par�metro 'files' devem estar abertos para leitura/escrita.
// P�s-condi��o: As informa��es do arquivo lote s�o registradas nos arquivos espec�ficos de acordo com a opera��o.
void ler_lote(ARQUIVOS files) {
    FILE *file_lote;
    char nome_arquivo[50];

    printf("\n--> Digite o nome do arquivo a ser lido (sem '.txt'): ");
    scanf("%49[^\n]%*c", nome_arquivo);
    strcat(nome_arquivo, ".txt");
    printf("%s\n", nome_arquivo);
    file_lote = fopen(nome_arquivo, "r");
    if (file_lote == NULL) {
        printf("\n--> erro ao ler arquivo..\n");
        return;
    }

    printf("\n--> Arquivo lido com sucesso...\n");

    char opcao[2];

    while (fscanf(file_lote, "%1s%*c", opcao) != EOF) {
        if (strcmp(opcao, "C") == 0) {
            registrar_lote_curso(file_lote, files.file_curso);
        } else if (strcmp(opcao, "D") == 0) {
            registrar_lote_disciplina(file_lote, files.file_disciplina);
        } else if (strcmp(opcao, "P") == 0) {
            registrar_lote_professor(file_lote, files.file_professor);
        } else if (strcmp(opcao, "M") == 0) {
            registrar_lote_distribuicao(file_lote, files.file_distribuicao);
        } else if (strcmp(opcao, "R") == 0) {
            remove_distribuicao(file_lote, files.file_distribuicao);
        }
    }

    fclose(file_lote);
}
