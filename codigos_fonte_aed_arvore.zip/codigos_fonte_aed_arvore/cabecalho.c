#include <stdio.h>
#include <stdlib.h>
#include "cabecalho.h"

// Função para criar uma lista nova em arquivo
// Pré-condição: O arquivo deve estar aberto para leitura/escrita
// Pós-condição: O arquivo é inicializado com uma lista vazia
void cria_arvore_vazia(FILE* arq){
    CABECALHO * cab = (CABECALHO*) malloc(sizeof(CABECALHO));
    cab->pos_raiz = -1;
    cab->pos_topo = 0;
    cab->pos_livre = -1;
    escreve_cabecalho(arq, cab);
    free(cab);
}

// Função para verificar se a árvore está vazia
// Pré-condição: O ponteiro para o cabeçalho deve ser válido
// Pós-condição: Retorna 1 se a árvore está vazia, 0 caso contrário
int is_vazia_arvore(CABECALHO * cab){
    return (cab->pos_raiz == -1);
}

// Função para ler o cabeçalho do arquivo contendo as informações da lista
// Pré-condição: O arquivo deve estar aberto e ser um arquivo de lista
// Pós-condição: Retorna o ponteiro para o cabeçalho lido
CABECALHO* le_cabecalho(FILE * arq) {
    CABECALHO * cab = (CABECALHO*) malloc(sizeof(CABECALHO));
    fseek(arq, 0, SEEK_SET); // Posiciona no início do arquivo
    fread(cab, sizeof(CABECALHO), 1, arq);
    return cab;
}

// Função para escrever no arquivo o cabeçalho contendo as informações da lista
// Pré-condição: O arquivo deve estar aberto e ser um arquivo de lista
// Pós-condição: O cabeçalho é escrito no arquivo
void escreve_cabecalho(FILE* arq, CABECALHO* cab){
    fseek(arq, 0, SEEK_SET); // Posiciona no início do arquivo
    fwrite(cab, sizeof(CABECALHO), 1, arq);
}
