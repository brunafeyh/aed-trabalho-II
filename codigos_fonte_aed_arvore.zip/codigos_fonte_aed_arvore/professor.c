#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "professor.h"  // Troquei para o arquivo "professor.h"
#include "cabecalho.h"
#include "file.h"

// Função para ler informações de um professor a partir da entrada padrão
// Pré-condição: Nenhuma.
// Pós-condição: Retorna um professor com dados lidos da entrada padrão.
PROFESSOR ler_professor(){
    PROFESSOR professor;
    printf("\n--> CADASTRO DE PROFESSOR: \n");
    printf("Insira o codigo do professor: ");
    scanf("%d%*c", &professor.codigo);
    printf("Insira o nome do professor: ");
    scanf("%[^\n]%*c", professor.nome);

    return professor;
}

// Função para ler um nó de professor de um arquivo na posição 'pos'
// Pré-condição: O arquivo está aberto e na posição 'pos' contém um nó de professor.
// Pós-condição: Retorna um ponteiro para o nó de professor lido do arquivo.
NO_PROFESSOR * le_no_professor(FILE* file_professor, int pos) {
    NO_PROFESSOR* no_professor = (NO_PROFESSOR*)malloc(sizeof(NO_PROFESSOR));
    fseek(file_professor, sizeof(CABECALHO) + pos * sizeof(NO_PROFESSOR), SEEK_SET);
    fread(no_professor, sizeof(NO_PROFESSOR), 1, file_professor);
    return no_professor;
}

// Função para escrever um nó de professor em um arquivo na posição 'pos'
// Pré-condição: O arquivo está aberto e o ponteiro 'no_professor' aponta para um nó de professor válido.
// Pós-condição: O nó de professor é escrito no arquivo na posição 'pos'.
void escreve_no_professor(FILE* file_professor, NO_PROFESSOR * professor, int pos) {
    fseek(file_professor, sizeof(CABECALHO) + pos * sizeof(NO_PROFESSOR), SEEK_SET);
    fwrite(professor, sizeof(NO_PROFESSOR), 1, file_professor);
}

// Função para inserir um nó de professor em um arquivo na posição 'pos'
// Pré-condição: O arquivo está aberto e o ponteiro 'no_professor' aponta para um nó de professor válido.
// Pós-condição: O nó de professor é inserido no arquivo na posição 'pos'.
void inserir_professor_file(FILE* file_professor, NO_PROFESSOR * no_professor, int pos){
    CABECALHO * cab = le_cabecalho(file_professor);

    if(pos == -1){
        if(is_vazia_arvore(cab)) cab->pos_raiz=0;
        escreve_no_professor(file_professor, no_professor, cab->pos_topo);
        cab->pos_topo++;
        escreve_cabecalho(file_professor, cab);
    }

    NO_PROFESSOR * prox = le_no_professor(file_professor, pos);

    if(no_professor->professor.codigo < prox->professor.codigo){
        if(prox->esq == -1){
            prox->esq = cab->pos_topo;
            escreve_no_professor(file_professor, prox, pos);
            inserir_professor_file(file_professor, no_professor, -1);
        }
        else inserir_professor_file(file_professor, no_professor, prox->esq);
    } else {
        if(no_professor->professor.codigo > prox->professor.codigo){
            if(prox->dir == -1){
                prox->dir = cab->pos_topo;
                escreve_no_professor(file_professor, prox, pos);
                inserir_professor_file(file_professor, no_professor, -1);
            }
            else inserir_professor_file(file_professor, no_professor, prox->dir);
        }
    }

    free(prox);
    free(cab);
}

// Função para buscar um professor no arquivo pelo código, retorna a posição do professor se encontrado, -1 se não encontrado
// Pré-condição: O arquivo está aberto e no formato correto.
// Pós-condição: Retorna a posição do professor no arquivo se encontrado, -1 caso contrário.
int buscar_professor(FILE * file_professor, int cod, int pos){
    if(pos == -1) return -1;
    else{
        NO_PROFESSOR * professor = le_no_professor(file_professor, pos);
        if(professor->professor.codigo > cod) return buscar_professor(file_professor, cod, professor->esq);
        else if(professor->professor.codigo < cod) return buscar_professor(file_professor, cod, professor->dir);
        free(professor);
    }
    return pos;
}

// Função para inserir um novo professor no arquivo
// Pré-condição: O arquivo está aberto e no formato correto.
// Pós-condição: Um novo nó de professor é inserido no arquivo.
void inserir_professor(FILE* file_professor){
    CABECALHO * cab = le_cabecalho(file_professor);

    NO_PROFESSOR * no_professor = (NO_PROFESSOR*)malloc(sizeof(NO_PROFESSOR));
    no_professor->esq = no_professor->dir = -1;
    no_professor->professor = ler_professor();

    if(buscar_professor(file_professor, no_professor->professor.codigo, cab->pos_raiz) == -1){
        inserir_professor_file(file_professor, no_professor, cab->pos_raiz);
        printf("--> Cadastro de professor realizado com sucesso\n");
    }else{
        printf("--> Codigo de professor ja existente\n");
    }

    free(cab);
    free(no_professor);
}

// Função para inserir um novo professor no arquivo proveniente do arquivo lote txt.
// Pré-condição: O arquivo está aberto e no formato correto.
// Pós-condição: Um novo nó de professor é inserido no arquivo.
void inserir_professor_do_lote(FILE* file_professor, PROFESSOR professor){
    CABECALHO * cab = le_cabecalho(file_professor);

    NO_PROFESSOR * no_professor = (NO_PROFESSOR*)malloc(sizeof(NO_PROFESSOR));
    no_professor->esq = no_professor->dir = -1;
    no_professor->professor = professor;

    if(buscar_professor(file_professor, no_professor->professor.codigo, cab->pos_raiz) == -1){
        inserir_professor_file(file_professor, no_professor, cab->pos_raiz);
        printf("--> Cadastro de professor realizado com sucesso\n");
    }else{
        printf("--> Codigo de professor ja existente\n");
    }

    free(cab);
    free(no_professor);
}

// Função para imprimir as informações de um nó de professor
// Pré-condição: O ponteiro 'no_professor' aponta para um nó de professor válido.
// Pós-condição: As informações do nó de professor são impressas na saída padrão.
void imprimir_info_professor(NO_PROFESSOR * no_professor) {
    printf("| %03d     ", no_professor->professor.codigo);
    printf("%-50s |\n", no_professor->professor.nome);
   // printf("esq: %d   dir: %d  ", no_professor->esq, no_professor->dir);
}

// Função para imprimir em ordem (in-order) as informações dos professores na árvore a partir de um nó inicial
// Pré-condição: O arquivo 'file_professor' está aberto e contém dados válidos, 'pos_atual' é um índice válido na árvore.
// Pós-condição: As informações dos professores são impressas em ordem crescente a partir do nó com índice 'pos_atual'.
void imprimir_in_order_professor(FILE* file_professor, int pos_atual){

    if (pos_atual != -1) {
        NO_PROFESSOR * no_atual = le_no_professor(file_professor, pos_atual);

        imprimir_in_order_professor(file_professor, no_atual->esq);

        imprimir_info_professor(no_atual);

        imprimir_in_order_professor(file_professor, no_atual->dir);
    }
}

// Função para imprimir a lista de professores em ordem a partir do arquivo
// Pré-condição: O arquivo 'file_professor' está aberto e contém dados válidos.
// Pós-condição: As informações dos professores são impressas em ordem crescente de código.
void imprimir_lista_professor(FILE* file_professor) {
    CABECALHO *cab = le_cabecalho(file_professor);
    //imprimir_cabecalho(cab);

    if(is_vazia_arvore(cab)) printf("--> Nao ha professores cadastrados\n");
    else{
        printf(" -------------------- Lista de Professores ------------------\n");
        printf("| COD.    NOME                                               |\n");
        imprimir_in_order_professor(file_professor, cab->pos_raiz);
        printf(" ------------------------------------------------------------\n");
    }

    free(cab);
}
