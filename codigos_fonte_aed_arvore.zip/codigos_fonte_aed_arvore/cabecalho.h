#ifndef CABECALHO_H
#define CABECALHO_H

// Definição da estrutura do cabeçalho do arquivo
typedef struct {
    int pos_raiz; // Posição do início da lista
    int pos_topo; // 1ª posição não usada no fim do arquivo
    int pos_livre; // Posição do início da lista de nós livres
} CABECALHO;

// Função para imprimir as informações do cabeçalho da lista
// Pré-condição: O ponteiro para o cabeçalho deve ser válido
// Pós-condição: As informações do cabeçalho são impressas na tela
void imprimir_cabecalho(CABECALHO * cab);

// Função para criar uma arvore nova em arquivo
// Pré-condição: O arquivo deve estar aberto para leitura/escrita
// Pós-condição: O arquivo é inicializado com uma arvore vazia
void cria_arvore_vazia(FILE* arq);

// Função para verificar se a árvore está vazia
// Pré-condição: O ponteiro para o cabeçalho deve ser válido
// Pós-condição: Retorna 1 se a árvore está vazia, 0 caso contrário
int is_vazia_arvore(CABECALHO * cab);

// Função para ler o cabeçalho do arquivo contendo as informações da lista
// Pré-condição: O arquivo deve estar aberto e ser um arquivo de lista
// Pós-condição: Retorna o ponteiro para o cabeçalho lido
CABECALHO * le_cabecalho(FILE * arq);

// Função para escrever no arquivo o cabeçalho contendo as informações da lista
// Pré-condição: O arquivo deve estar aberto e ser um arquivo de lista
// Pós-condição: O cabeçalho é escrito no arquivo
void escreve_cabecalho(FILE* arq, CABECALHO* cab);

#endif //CABECALHO_H
