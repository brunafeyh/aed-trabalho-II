#include <stdio.h>
#include "menu.h"
#include "cabecalho.h"
#include "file.h"
#include "curso.h"

// Função principal do programa.
// Pré-condição: Nenhuma.
// Pós-condição: O programa é executado, interagindo com o usuário por meio do menu principal.
//               Os arquivos são abertos e verificados para garantir a consistência do sistema.
//               Ao final, os arquivos são fechados antes da conclusão do programa.
int main() {
    // Estrutura para armazenar os arquivos necessários.
    ARQUIVOS files;

    // Verifica a existência e integridade dos arquivos, abrindo-os se necessário.
    verificar_arquivos(&files);

    // Executa o menu principal, interagindo com o usuário e realizando as operações escolhidas.
    menu_principal(files);

    // Fecha os arquivos ao final da execução do programa.
    fechar_arquivos(&files);

    // Indica a conclusão bem-sucedida do programa.
    return 0;
}
