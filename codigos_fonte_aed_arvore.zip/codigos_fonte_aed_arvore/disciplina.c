#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "disciplina.h"
#include "cabecalho.h"
#include "file.h"

// Função para ler as informações de uma disciplina do usuário e retornar uma struct DISCIPLINA
// Pré-condição: Nenhuma
// Pós-condição: Retorna uma struct DISCIPLINA com as informações da disciplina inseridas pelo usuário
DISCIPLINA ler_disciplina(){
    DISCIPLINA disciplina;
    printf("\n--> CADASTRO DE DISCIPLINA: \n");
    printf("Insira o codigo da disciplina: ");
    scanf("%d%*c", &disciplina.codigo);
    printf("Insira o nome da disciplina: ");
    scanf("%[^\n]%*c", disciplina.nome);
    printf("Insira o codigo do curso da disciplina: ");
    scanf("%d", &disciplina.cod_curso);
    printf("Insira o ano da disciplina: ");
    scanf("%d", &disciplina.serie);

    return disciplina;
}

// Função para ler um nó em uma determinada posição do arquivo
// Pré-condição: O arquivo deve estar aberto e ser um arquivo de lista, pos deve ser uma posição válida da lista
// Pós-condição: Retorna um ponteiro para o nó lido do arquivo
NO_DISCIPLINA * le_no_disciplina(FILE* file_disciplina, int pos) {
    NO_DISCIPLINA* no_disciplina = (NO_DISCIPLINA*)malloc(sizeof(NO_DISCIPLINA));
    fseek(file_disciplina, sizeof(CABECALHO) + pos * sizeof(NO_DISCIPLINA), SEEK_SET);
    fread(no_disciplina, sizeof(NO_DISCIPLINA), 1, file_disciplina);
    return no_disciplina;
}

// Função para escrever um nó em uma determinada posição do arquivo
// Pré-condição: O arquivo deve estar aberto e ser um arquivo de lista, pos deve ser uma posição válida do arquivo
// Pós-condição: O nó é escrito no arquivo na posição especificada
void escreve_no_disciplina(FILE* file_disciplina, NO_DISCIPLINA * disciplina, int pos) {
    fseek(file_disciplina, sizeof(CABECALHO) + pos * sizeof(NO_DISCIPLINA), SEEK_SET);
    fwrite(disciplina, sizeof(NO_DISCIPLINA), 1, file_disciplina);
}

// Função para inserir um nó contendo as informações da disciplina em uma determinada posição do arquivo
// Pré-condição: O arquivo deve estar aberto
// Pós-condição: O nó é escrito no arquivo na posição apropriada, e o cabeçalho é atualizado se necessário
void inserir_disciplina_file(FILE* file_disciplina, NO_DISCIPLINA * no_disciplina, int pos){
    CABECALHO * cab = le_cabecalho(file_disciplina);

    if(pos == -1){//pos_raiz == -1 árvore vazia ou a função recebeu uma posição (pos) vazia
        if(is_vazia_arvore(cab)) cab->pos_raiz=0;//cabeca apenas alterada se for a primeira insersão (-1 -> 0)
        escreve_no_disciplina(file_disciplina, no_disciplina, cab->pos_topo);//escreve o novo nó na proxima posicao livre
        cab->pos_topo++;
        escreve_cabecalho(file_disciplina, cab);
    }

    NO_DISCIPLINA * prox = le_no_disciplina(file_disciplina, pos);

    if(no_disciplina->disciplina.codigo < prox->disciplina.codigo){
        if(prox->esq == -1){
            prox->esq = cab->pos_topo;
            escreve_no_disciplina(file_disciplina, prox, pos);
            inserir_disciplina_file(file_disciplina, no_disciplina, -1);//como a posicao esquerda foi alterada, manda-se -1
        }
        else inserir_disciplina_file(file_disciplina, no_disciplina, prox->esq);//envia a proxima posicao para ser testada
    } else {
        if(no_disciplina->disciplina.codigo > prox->disciplina.codigo){
            if(prox->dir == -1){
                prox->dir = cab->pos_topo;
                escreve_no_disciplina(file_disciplina, prox, pos);
                inserir_disciplina_file(file_disciplina, no_disciplina, -1);//como a posicao direita foi alterada, manda-se -1
            }
            else inserir_disciplina_file(file_disciplina, no_disciplina, prox->dir);//envia a proxima posicao para ser testada
        }
    }

    free(prox);
    free(cab);
}

// Função para buscar uma disciplina no arquivo pelo código
// Pré-condição: O arquivo deve estar aberto, cod é o código a ser buscado, pos é a posição inicial da busca
// Pós-condição: Retorna a posição da disciplina com o código especificado, -1 se não encontrado
int buscar_disciplina(FILE * file_disciplina, int cod, int pos){
    if(pos == -1) return -1; // Caso a raiz seja nula, não ha elementos na arvore
    else{
        NO_DISCIPLINA * disciplina = le_no_disciplina(file_disciplina, pos);
        if(disciplina->disciplina.codigo > cod) return buscar_disciplina(file_disciplina, cod, disciplina->esq);//todos os codigos menores que a raiz se encontram a esquerda
        else if(disciplina->disciplina.codigo < cod) return buscar_disciplina(file_disciplina, cod, disciplina->dir);//todos os codigos maiores que a raiz se encontram a direita
        free(disciplina);
    }
    return pos;
}

// Função para inserir uma disciplina no arquivo
// Pré-condição: O arquivo deve estar aberto
// Pós-condição: A disciplina é inserida no arquivo, e uma mensagem é exibida indicando o resultado da operação
void inserir_disciplina(FILE* file_disciplina){
    CABECALHO * cab = le_cabecalho(file_disciplina);

    NO_DISCIPLINA * no_disciplina = (NO_DISCIPLINA*)malloc(sizeof(NO_DISCIPLINA));
    no_disciplina->esq = no_disciplina->dir = -1;
    no_disciplina->disciplina = ler_disciplina();

    if(buscar_disciplina(file_disciplina, no_disciplina->disciplina.codigo, cab->pos_raiz) == -1){
        inserir_disciplina_file(file_disciplina, no_disciplina, cab->pos_raiz);
        printf("--> Cadastro de disciplina realizado com sucesso\n");
    }else{
        printf("--> Codigo de disciplina ja existente\n");
    }

    free(cab);
    free(no_disciplina);
}

// Função para inserir uma disciplina no arquivo proveniente do arquivo lote txt
// Pré-condição: O arquivo deve estar aberto
// Pós-condição: A disciplina é inserida no arquivo, e uma mensagem é exibida indicando o resultado da operação
void inserir_disciplina_do_lote(FILE* file_disciplina, DISCIPLINA disciplina){
    CABECALHO * cab = le_cabecalho(file_disciplina);

    NO_DISCIPLINA * no_disciplina = (NO_DISCIPLINA*)malloc(sizeof(NO_DISCIPLINA));
    no_disciplina->esq = no_disciplina->dir = -1;
    no_disciplina->disciplina = disciplina;

    if(buscar_disciplina(file_disciplina, no_disciplina->disciplina.codigo, cab->pos_raiz) == -1){
        inserir_disciplina_file(file_disciplina, no_disciplina, cab->pos_raiz);
        printf("--> Cadastro de disciplina realizado com sucesso\n");
    }else{
        printf("--> Codigo de disciplina ja existente\n");
    }

    free(cab);
    free(no_disciplina);
}

// Função para imprimir as informações de uma disciplina contidas em um nó
// Pré-condição: O nó deve ser válido
// Pós-condição: As informações da disciplina no nó são impressas na tela
void imprimir_info_disciplina(NO_DISCIPLINA * no_disciplina, NO_CURSO * no_curso) {
    printf("| %03d    ", no_disciplina->disciplina.codigo);
    printf("%-50s", no_disciplina->disciplina.nome);
    printf("%d          ", no_disciplina->disciplina.cod_curso);
    printf("%-50s", no_curso->curso.nome);
    printf(" %d  |\n", no_disciplina->disciplina.serie);
}

// Função para imprimir as disciplinas em ordem no arquivo
// Pré-condição: O arquivo deve estar aberto e conter disciplinas
// Pós-condição: As disciplinas são impressas em ordem na tela
void imprimir_in_order_disciplina(ARQUIVOS files, int pos_atual){
    if (pos_atual != -1) {
        NO_DISCIPLINA * no_atual = le_no_disciplina(files.file_disciplina, pos_atual);

        // Recursivamente imprime a subárvore esquerda
        imprimir_in_order_disciplina(files, no_atual->esq);

        NO_CURSO * no_curso = buscar_info_curso(files, no_atual->disciplina.cod_curso);
        imprimir_info_disciplina(no_atual, no_curso);
        free(no_curso);

        // Recursivamente imprime a subárvore direita
        imprimir_in_order_disciplina(files, no_atual->dir);
    }
}

// Função para imprimir as disciplinas em ordem no arquivo
// Pré-condição: O arquivo deve estar aberto e conter disciplinas
// Pós-condição: As disciplinas são impressas em ordem na tela
void imprimir_lista_disciplinas(ARQUIVOS files) {
    CABECALHO *cab = le_cabecalho(files.file_disciplina);
    //imprimir_cabecalho(cab);

    if(is_vazia_arvore(cab)) printf("--> Nao ha cursos cadastradas\n");
    else{
        printf(" --------------------------------------------------- Lista de Disciplinas --------------------------------------------------\n");
        printf("| COD.   NOME                                          COD. CUR.      NOME CURSO                                       SERIE|\n");
        imprimir_in_order_disciplina(files, cab->pos_raiz);
        printf(" ----------------------------------------------------------------------------------------------------------------------------\n");
    }

    free(cab);
}
